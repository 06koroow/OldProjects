// Fetch Data and Mapp HTML from the JSON Object it grabs from 'database.db'
function fetchData(){
    console.log('lookingfordata');
    fetch("../config/database.db").then(response => {
    if (!response.ok){
        throw Error ('ERROR')
    }
    return response
    .json()
    }).then(data => {
        const content = data
        .filter(function (el) {
            return el != null;
        })
        .map(content => {  
        //now mapping the HTML using string interpolation/template litterals
        return `
        <h1 class="bodyHeader content" href="${content.heading}">${content.heading}</h1>
        <p class="textArea content"> ${content.text}</p>
        <img class="photo content" src="${content.photo}" alt=""></img>
        `
    })
    //removing the comma joing
    .join(" ");
    //pointing the function to the DOM and giving it the container.
        document
        .querySelector('#contentContainer')
        .innerHTML = content
        console.log(content)
        }).catch(error => {
            console.log(error)
        })
};
    fetchData();




